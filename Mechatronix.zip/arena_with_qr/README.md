---Changes all of the paths

roslaunch arena_with_qr launch_in_gz.launch 

rosrun arena_with_qr grid_following.py

---Run after exiting grid

rosrun arena_with_qr line_following.py 

--- Can be run at spawn point, values are extracted but code is not integrated

rosrun arena_with_qr qr_detect.py 

--- Was run separately to get shortest path

Execute main.py to get Djikstra Path(not integrated)

--- All the codes are there but integration was left
